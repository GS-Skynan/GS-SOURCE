#ifndef __RS485IIC_H__
#define __RS485IIC_H__
#include"../../SYS/src/sys.h"
#include"../../APBAT/scr/apbat.h"
#include"../../../mcc_generated_files/mcc.h"       

extern  uint RS485_Flag_Start;
extern  uint RS485_Flag_Start_count;

void RS485(void);
void SData_to_wierless(uchar date);                                              /*�������ݸ�����ģ��*/
void Send_Date_to_Driver(uchar *arr_buff2, uchar len2);                          /*�������ݸ�����*/
char HexToAscii(char nHex);
char AsciiToHex(char nAscii);
void Senddate_to_Wireless02(void);   
void READ_NFC_LINE(void);
#endif