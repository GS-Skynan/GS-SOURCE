#ifndef __LED_H__
#define __LED_H__
#include"../../APBAT/scr/apbat.h"
unsigned char  usart_flag;
unsigned char  LED_R_flag;

void LED_RGB(void);

#endif