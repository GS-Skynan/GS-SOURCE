#ifndef __NFC_H__
#define __NFC_H__
//#define ROW_SIZE 4                                                              // ÿ��4�ֽ�
//#define I2C_ADDRESS  0x53
#define ROW_MAX   64   // ST25DV04K �� 64 ��
#define COL_MAX   4   // ÿ�� 4 �ֽ�
#include"../../APBAT/scr/apbat.h"
#include "../../../mcc_generated_files/examples/i2c1_master_example.h"
extern unsigned char  Write_NFC[62]={0x00,0x00};                                       //ǰ������Ϊ��Ҫ���ĵĵ�ַ
/*NFC*/
unsigned char  I2C_sendAdd[2];                                      //WRITE ADDRESS 
unsigned char  I2C_sendAdd_2[3];
extern unsigned char  I2C_password_add[19]={0x09,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x09,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
unsigned char  I2C_receiveData[61];
unsigned char  I2C_R_system_config_Data[1];
//��ȡNFC�ϵ����ֵ
extern unsigned int   NFC_CH1,NFC_CH2;                                                 //,NFC_CH3=0,NFC_CH4=0;          
extern unsigned int   read_NFC_Date5,read_NFC_Date6,read_NFC_Date7;
extern unsigned int   read_NFC_Date8,NFC_SN_Num;

void READ_NFC_SET_START(void);
bool ReadByte_RowCol(uint8_t i2cAddr, uint8_t row, uint8_t col, uint8_t *value);
bool WriteByte_RowCol(uint8_t i2cAddr, uint8_t row, uint8_t col, uint8_t num);
#endif