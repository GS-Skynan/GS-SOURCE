#include"../scr/nfc.h"
    uchar d=0;
    unsigned char GPO_config_value = 0;
    unsigned char I2C_sendAdd_2[3]={0x00,0x00,0xC0};
void READ_NFC_SET_START(void)
{
     unsigned int NFC_CH1=0,NFC_CH2=0; 
     unsigned char I2C_sendAdd[2] = {0};
     unsigned char NFC_SN_Year = 0,NFC_SN_Week = 0;
     unsigned char NFC_default_ON_OFF_CH1=0,NFC_default_ON_OFF_CH2=0,NFC_default_ON_OFF_CH3=0,NFC_default_ON_OFF_CH4=0;
     unsigned int read_NFC_Date5=0,read_NFC_Date6=0,read_NFC_Date7=0, read_NFC_Date8 = 0,NFC_SN_Num = 0;
     unsigned char NFC_LFR_1 = 0,NFC_LFR_2 = 0,NFC_LFR_3 = 0,NFC_Group_100 = 0,NFC_Group_16 = 0,NFC_Group = 0;
    I2C1_WriteNBytes(0x57,I2C_sendAdd_2,2);                                         //write system configuration //0x0000
    I2C1_ReadNBytes(0x57,I2C_R_system_config_Data,sizeof(I2C_R_system_config_Data));//read system configuration //0x0000
    delay(5);                                                                       //0
    GPO_config_value=I2C_R_system_config_Data[0];
    delay(5);                                                                       //1
    
    if(GPO_config_value==0XC0)
    {
      NOP();                                                                        // RC2=1;      
    }
    else                                                                            //----------Enable ST25DV04K GPO password------DIVECE-0X57---//
    {
        NOP();
        I2C1_WriteNBytes(0x57,I2C_password_add,19);
        delay(10);                                                                  //5
        I2C1_WriteNBytes(0x57,I2C_sendAdd_2,3); 
        delay(2);                                                                   //1
    }    
    I2C1_WriteNBytes(0x53,I2C_sendAdd,2);                                           //write NFC USE MEMORY address
    I2C1_ReadNBytes(0x53,I2C_receiveData,60);                                       //read NFC USE MEMORY data //sizeof(I2C_receiveData
    delay(5);                                                                       //10
    
    NFC_default_ON_OFF_CH1=I2C_receiveData[0];
    NFC_default_ON_OFF_CH2=I2C_receiveData[4];
    NFC_default_ON_OFF_CH3=I2C_receiveData[8];
    NFC_default_ON_OFF_CH4=I2C_receiveData[12];
    
    NFC_CH1=(unsigned int)(I2C_receiveData[2]<<8)+I2C_receiveData[3];             //00�к���λ    һͨ������    
    NFC_CH2=(unsigned int)(I2C_receiveData[6]<<8)+I2C_receiveData[7];             //01�к���λ    ��ͨ������
    read_NFC_Date5=(unsigned int)(I2C_receiveData[18]<<8)+I2C_receiveData[19];      //04�к���λ    ��ͨ������
    read_NFC_Date6=(unsigned int)(I2C_receiveData[22]<<8)+I2C_receiveData[23];      //05�к���λ    ��ͨ������
    read_NFC_Date7=(unsigned int)(I2C_receiveData[26]<<8)+I2C_receiveData[27];      //06�к���λ    ��ͨ������
    read_NFC_Date8=(unsigned int)(I2C_receiveData[30]<<8)+I2C_receiveData[31];      //07�к���λ    ��ͨ������
    
    NFC_ruwang=I2C_receiveData[36];                                                 //����Dongle����  00��������ģʽ��01����������������02����ATָ��ģʽ
    NFC_Start_time=((I2C_receiveData[37]>>4)*10+(I2C_receiveData[37]&0x0F))*100;    //ת����msΪ��λ��ʱ��
    NFC_Group_100=I2C_receiveData[38];                                             //09�е�������  ����Ű�λ
    NFC_Group_16=I2C_receiveData[39];                                              //09�е��ĸ���  �����
    NFC_Group=NFC_Group_16>>4;                                                     //ʮλ��
    NFC_Group=NFC_Group*10;
    NFC_Group=NFC_Group_100*100+NFC_Group+(NFC_Group_16&0x0F);                     //NFC16����ת��Ϊ10����    
    
    /*�ز�Ƶ��ʹ��ֱ����ʽ*/
    NFC_LFR_1=I2C_receiveData[41];                                                //��Ƶ�ʵ����λ
    NFC_LFR_2=I2C_receiveData[42];                                                //��Ƶ�ʵ��м�λ
    NFC_LFR_3=I2C_receiveData[43];                                                //��Ƶ�ʵ����λ
    at_rx2[9]=((I2C_receiveData[41]>>4)+48);
    at_rx2[10]=((I2C_receiveData[41]&0x0f)+48);
    at_rx2[11]=((I2C_receiveData[42]>>4)+48);
    at_rx2[12]=((I2C_receiveData[42]&0x0f)+48);
    at_rx2[13]=((I2C_receiveData[43]>>4)+48);
    at_rx2[14]=((I2C_receiveData[43]&0x0f)+48);
    
    /*�ز�Ƶ��ʹ���ŵ�ģʽ*/
    NFC_SN_Year=I2C_receiveData[44];                                              //11�е�һλ  SN����
    NFC_SN_Week=I2C_receiveData[45];                                              //11�еڶ�λ  SN����
    NFC_SN_Num=(unsigned int)(I2C_receiveData[46]<<8)+I2C_receiveData[47];        //11�е�������λ  SN����������
    
    while(d<60)
    {
        Write_NFC[d+2]=I2C_receiveData[d];                                        //��NFC�յ������ݸ�����Write_NFC��
        d++;
    }        
}

void decrypt()                                                                       //����
{
    I2C1_WriteNBytes(0x57,I2C_sendAdd_2,2);                                         //write system configuration //0x0000
    I2C1_ReadNBytes(0x57,I2C_R_system_config_Data,sizeof(I2C_R_system_config_Data));//read system configuration //0x0000
    delay(5);                                                                       //0
    GPO_config_value=I2C_R_system_config_Data[0];
    delay(5);                                                                       //1
    
    if(GPO_config_value==0XC0)
    {
      NOP();                                                                        // RC2=1;      
    }
    else                                                                            //----------Enable ST25DV04K GPO password------DIVECE-0X57---//
    {
        NOP();
        I2C1_WriteNBytes(0x57,I2C_password_add,19);
        delay(10);                                                                  //5
        I2C1_WriteNBytes(0x57,I2C_sendAdd_2,3); 
        delay(2);                                                                   //1
    }    
  }  

bool ReadByte_RowCol(uint8_t i2cAddr, uint8_t row, uint8_t col, uint8_t *value)
{
    if (row >= ROW_MAX || col >= COL_MAX || value == NULL) {
        return false;                                                           // �����Ƿ�
    }
    uint16_t regAddress = (row - 1)* row  + col - 1;
    uint8_t regAddrBuf[2];
    regAddrBuf[0] = (uint8_t)(regAddress >> 8);                                 // ���ֽ�
    regAddrBuf[1] = (uint8_t)(regAddress & 0xFF);                               // ���ֽ�
    decrypt();
    I2C1_WriteNBytes(i2cAddr, regAddrBuf, 2);                                   // д��Ĵ�����ַ
    delay(10);
    I2C1_ReadNBytes(i2cAddr,value, 1);                                         // ��һ���ֽ�                                            
    delay(10);
    
   return true;
}
bool WriteByte_RowCol(uint8_t i2cAddr, uint8_t row, uint8_t col, uint8_t num)
{
    if (row >= ROW_MAX || col >= COL_MAX ) {
        return false;                                                           // �����Ƿ�
    }
    uint16_t regAddress = (row - 1) * COL_MAX + (col - 1);
    uint8_t regAddrBuf[3];
    regAddrBuf[0] = (uint8_t)(regAddress >> 8);                                 // ���ֽ�
    regAddrBuf[1] = (uint8_t)(regAddress & 0xFF);                               // ���ֽ�
    regAddrBuf[2] = num;
    decrypt();
    I2C1_WriteNBytes(i2cAddr, regAddrBuf, 3);                                   // д��Ĵ�����ַ
    delay(10);
    
   return true;
}
