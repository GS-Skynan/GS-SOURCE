#include"../src/sys.h"
void delay(unsigned int z)                                                      //delay(1)=2ms
{
   unsigned int x,y;
    for(x=1000;x>0;x--)
    {
        for(y=z;y>0;y--);
    }    
}
