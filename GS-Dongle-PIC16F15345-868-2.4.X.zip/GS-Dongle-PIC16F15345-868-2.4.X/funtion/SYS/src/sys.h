#ifndef __SYS_H__
#define __SYS_H__
#include <xc.h>
#include "pic16f15345.h"
#define 	uchar   unsigned char
#define 	uint 	unsigned int
#define  LED_R_ON          (RA4=0,LATA4=0,RC4=1,LATC4=1,RC5=1,LATC5=1)
#define  LED_R_OFF         (RA4=1,LATA4=1)
#define  LED_B_ON          (RC4=0,LATC4=0,RC5=1,LATC5=1,RA4=1,LATA4=1)
#define  LED_B_OFF         (RC4=1,LATC4=1)
#define  LED_G_ON          (RC5=0,LATC5=0,RC4=1,LATC4=1,RA4=1,LATA4=1)
#define  LED_G_OFF         (RC5=1,LATC5=1)
#define  W_RST_OFF         (RC6=0,LATC6=0)
#define  W_RST_ON          (RC6=1,LATC6=1)
#define  MODE_AT_OFF       (RC7=1,LATC7=1)
#define  MODE_AT_ON        (RC7=0,LATC7=0)
#define  WAKE_OFF          (RC3=1,LATC3=1)
#define  WAKE_ON           (RC3=0,LATC3=0)
#define  IO_485_R          (RA2=0,LATA2=0)
#define  IO_485_W          (RA2=1,LATA2=1)
/*MCU��������Ƭ����ָ��*/
unsigned char  MCU_to_Driver_10[17]={0x00,0x10,0x00,0x0E,0x00,0x04,0x08,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};      //�����������������ݵ�����
unsigned char  MCU_to_Driver_11[17]={0x00,0x11,0x00,0x0E,0x00,0x04,0x08,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};      //�����������������ݵ�����
unsigned char  MCU_to_Driver_12[17]={0x00,0x12,0x00,0x0E,0x00,0x04,0x08,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};      //�����������������ݵ�����
unsigned char  NFC_default_ON_OFF_CH1,NFC_default_ON_OFF_CH2,NFC_default_ON_OFF_CH3,NFC_default_ON_OFF_CH4;
/*��ѯaddr*/
unsigned char  at_check_devaddr[13]={0x61,0x74,0x2B,0x64,0x65,0x76,0x61,0x64,0x64,0x72,0x3F,0x0D,0x0A};                //at+devaddr?
unsigned char  at_check_rx2[9]={0x61,0x74,0x2B,0x72,0x78,0x32,0x3F,0x0D,0x0A};                                         //at+rx2?
unsigned int   PID_num;
unsigned char  PID_first_num,PID_second_num,PID_third_num,PID_fourth_num,PID_fifth_num;
unsigned int   TPR_num;
unsigned char  TPR_first_num,TPR_second_num;

extern unsigned char flag_485;
extern unsigned char LED_R_1s_flag,LED_B_1s_flag,Start_min_flag;                                                       //LED_G_1s_flag
extern uint Rx_Buffer[50];

void delay(unsigned int z);


#endif