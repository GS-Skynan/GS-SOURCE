
#include "interrupt_manager.h"
#include "mcc.h"
#include "../funtion/RS485/src/rs485iic.h"
#include"../funtion/LED/src/led.h"
unsigned char flag_485=0;
unsigned char count_485=0,R485_FLAG=0,count=0;
unsigned int  usart_count,LED_R_count=0,LED_B_count=0,Start_min_count=0;
unsigned char LED_R_1s_flag=0,LED_B_1s_flag=0,Start_min_flag=0;//LED_G_1s_flag=1,
unsigned int  tmfcon,RS485_Flag_Start,RS485_Flag_Start_count,NFC_Start_time;
uint Rx_Buffer[50];
void __interrupt() INTERRUPT_InterruptManager (void)
{
    unsigned char usart_flag = 0;
    unsigned char Rx_Lenght = 0;
    // interrupt handler
    if(PIE0bits.TMR0IE == 1 && PIR0bits.TMR0IF == 1)
    {
        TMR0_ISR();
        count++;                            //100=100ms
        tmfcon++;
        LED_R_count++;
        LED_B_count++;     
        if(count==100)                    //100ms
        {
            usart_count++;
            count_485++;
            Start_min_count++;
            count=0;
        }
        if(250==LED_B_count)
        if(RS485_Flag_Start_count)
        {
            RS485_Flag_Start = 1;
            RS485_Flag_Start_count--;
        }
        if(usart_count==50)
        {
            usart_count=0;
            usart_flag=1;
        }
        if(count_485==5)
        {
            flag_485=1;
            count_485=0;
        }
        if(tmfcon>=150)                   //150ms 
        {      
            Rx_Lenght=0;
        }
        if(tmfcon>=500)                   //500ms
        {   
            tmfcon=0; 
            R485_FLAG=0;
        }
        if(LED_R_count>=500)                   
        {   
            LED_R_1s_flag=1;
        }
        if(LED_R_count>=1000)                   
        {   
            LED_R_1s_flag=0;
            LED_R_count=0;
        }
        if(LED_B_count>=500)                   
        {   
            LED_B_1s_flag=1;
        }
        if(LED_B_count>=1000)                   
        {   
            LED_B_1s_flag=0;
            LED_B_count=0;
        }
        if(Start_min_count>=NFC_Start_time)                  //2����     
        {
            Start_min_flag=1;
            Start_min_count=0;
        }
    }   
    else if(INTCONbits.PEIE == 1)
    {
        if(PIE3bits.RC2IE == 1 && PIR3bits.RC2IF == 1)      /*��������ģ�鷢�͵�����*/
        {
            usart_count=0;
            usart_flag=0;
            tmfcon=0;
            EUSART2_RxDefaultInterruptHandler();
            Rx_Buffer[Rx_Lenght] = EUSART2_Read();
            Rx_Lenght++;
            PIR3bits.RC2IF = 0;
            R485_FLAG=1;
        }        
        else if(PIE3bits.RC1IE == 1 && PIR3bits.RC1IF == 1)
        {
            EUSART1_RxDefaultInterruptHandler();
        } 
        else if(PIE3bits.TX2IE == 1 && PIR3bits.TX2IF == 1)
        {
            EUSART2_TxDefaultInterruptHandler();
        } 
        else if(PIE3bits.TX1IE == 1 && PIR3bits.TX1IF == 1)
        {
            EUSART1_TxDefaultInterruptHandler();
        } 
        else
        {
            //Unhandled Interrupt
        }
    }
    else
    {
        //Unhandled Interrupt
    }
}
/**
 End of File
*/
